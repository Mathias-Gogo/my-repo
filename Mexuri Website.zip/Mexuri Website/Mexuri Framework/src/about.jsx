

export default function About() {
    return(
        <div>
            <h1> About Page</h1>
            <p> Mexuri Framework is a modern web development framework that simplifies the process of building web applications. </p>
            <p> It provides a set of tools and libraries that make it easy to create responsive and dynamic web applications. </p>
            <p> With Mexuri Framework, you can focus on building your application without worrying about the underlying technology. </p>
            <p> It is designed to be easy to use and flexible, allowing developers to create applications that meet their specific needs. </p>
            <p> Whether you are a beginner or an experienced developer, Mexuri Framework has something to offer. </p>
            <p> It is built on top of modern web technologies such as React, Redux, and Webpack, making it a powerful and efficient framework for building web applications. </p>
        </div>
    );
}